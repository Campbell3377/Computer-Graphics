I felt compelled to add that I am aware that I should have seperated
the geometry to its own js file, but I never figured out how to 
properly do that as Ive never worked in js and none of the demos
show that kind of thing. Anyways, I didn't really see it as important 
while figuring everything out and now I don't believe it is worth 
splitting my js file simply for the sake for of them being seperate.